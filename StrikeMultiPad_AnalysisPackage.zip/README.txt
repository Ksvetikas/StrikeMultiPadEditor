This is a compact analysis extract from an Alesis Strike MultiPad PACKBKF backup.
It includes every detected KITC/KITH physical record, the factory list tables,
the KITI-to-50xx translation run, the backup prefix, and the metadata region.
It does not include the large audio/sample payload data.
Offsets in the manifest refer to the original backup file.
